
import React from 'react';
import { Trainer, ClassInfo, MembershipPlan } from './types';

export const COLORS = {
  primary: '#FF6B4A',
  textDark: '#1a1a1a',
  textLight: '#4b5563',
  bgGray: '#e5e7eb',
};

export const TRAINERS: Trainer[] = [
  {
    name: 'Hloni Maboko',
    role: 'Personal Trainer',
    bio: "I'm a 35 years old personal trainer and professional boxing coach from Johannesburg Gauteng. I've completed a Certificate in Personal Fitness, Training and Diploma in Marketing and looking for fresh opportunities.",
    imageUrl: 'https://picsum.photos/400/500?random=1',
  },
  {
    name: 'Njabulo Buthelezi',
    role: 'Personal Trainer',
    bio: "I'm a professional boxer, and a personal trainer with a certificate in personal training fitness. I'm 28 years old of age Work Experience: Planet Fitness, Fight Club, We Box, Urban Warrior Gym.",
    imageUrl: 'https://picsum.photos/400/500?random=2',
  }
];

export const CLASSES: ClassInfo[] = [
  {
    id: 'rise-and-grind',
    title: 'ROCKET RISE & GRIND',
    subtitle: '(Morning & Evening CIRCUIT)',
    description: 'Master the sweet science of boxing with our comprehensive combat training program. Develop razor-sharp boxing movements through punch bag work, precision mitt drills, shadow boxing routines, and controlled touch sparring.',
    benefits: ['Improve strength & speed', 'Hand to eye coordination', 'Improve cardio', 'Helps with weight loss'],
  },
  {
    id: 'power-punch',
    title: 'ROCKET POWER PUNCH',
    subtitle: '(STRENGTH)',
    description: 'Build a foundation of raw power through focused compound movements and resistance training. This session prioritizes perfect form and progressive overload.',
    benefits: ['Raw strength gain', 'Bone density', 'Metabolic burn'],
  },
  {
    id: 'toning',
    title: 'ROCKET TONING',
    subtitle: '(LEGS & GLUTES)',
    description: 'A targeted sculpting session focused on lower-body aesthetics and structural stability.',
    benefits: ['Shape & definition', 'Stabilization', 'Functional strength'],
  },
  {
    id: 'box-lab',
    title: 'ROCKET BOX LAB',
    subtitle: '(TECHNIQUE)',
    description: 'From footwork to punching precision, this "lab" environment breaks down the mechanics of boxing to sharpen your reflexes.',
    benefits: ['Technical precision', 'Reflex speed', 'Boxing IQ'],
  },
  {
    id: 'energy-exchange',
    title: 'ROCKET ENERGY EXCHANGE',
    subtitle: '(HIIT)',
    description: 'An explosive, high-intensity interval training session designed for maximum calorie expenditure.',
    benefits: ['V02 Max improvement', 'Endurance', 'Fat burn'],
  },
  {
    id: 'bootcamp',
    title: 'ROCKET BOOTCAMP',
    subtitle: '(MUSCLE ENDURANCE)',
    description: 'Test your grit with high-volume functional training. This session focuses on muscular endurance and cardiovascular resilience.',
    benefits: ['Mental grit', 'Stamina', 'Full body conditioning'],
  },
  {
    id: 'box-flex',
    title: 'ROCKET BOX FLEX',
    subtitle: '(FLEXIBILITY)',
    description: 'Recovery and mobility focused session using stretching and guided movement.',
    benefits: ['Recovery', 'Mobility', 'Injury prevention'],
  }
];

export const GROUP_MEMBERSHIPS: MembershipPlan[] = [
  {
    name: 'OFF PEAK MEMBERSHIP',
    access: ['Unlimited Access Off Peak', 'Unlimited Classes', 'Unlimited Gym Access'],
    cta: 'Book Now',
  },
  {
    name: 'PEAK MEMBERSHIP',
    access: ['Unlimited Access in Peak', 'Unlimited Classes', 'Unlimited Gym Access'],
    cta: 'Book Now',
  }
];

export const PRIVATE_MEMBERSHIPS: MembershipPlan[] = [
  { name: 'UNLEASHED 1', access: ['1 Private Per Week', 'Unlimited Classes', 'Unlimited Gym Access'], cta: 'Button' },
  { name: 'UNLEASHED 2', access: ['2 Private Per Week', 'Unlimited Classes', 'Unlimited Gym Access'], cta: 'Button' },
  { name: 'UNLEASHED 3', access: ['3 Private Per Week', 'Unlimited Classes', 'Unlimited Gym Access'], cta: 'Button' },
  { name: 'UNLEASHED DUO 1', access: ['1 Privates Per Week With a Partner', 'Unlimited Classes', 'Unlimited Gym Access'], cta: 'Button', isDuo: true },
  { name: 'UNLEASHED DUO 2', access: ['1 Privates Per Week With a Partner', 'Unlimited Classes', 'Unlimited Gym Access'], cta: 'Button', isDuo: true },
  { name: 'UNLEASHED DUO 3', access: ['1 Privates Per Week With a Partner', 'Unlimited Classes', 'Unlimited Gym Access'], cta: 'Button', isDuo: true },
];
