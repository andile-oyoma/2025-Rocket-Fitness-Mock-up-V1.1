
import React from 'react';
import { Link } from 'react-router-dom';
import { Network, Home, Users, User, CreditCard, ChevronRight, ImageIcon } from 'lucide-react';

export const SiteMap: React.FC = () => {
  const mapData = [
    {
      title: 'Primary Entry',
      icon: <Home className="w-5 h-5" />,
      items: [{ label: 'Home Page', path: '/' }]
    },
    {
      title: 'Class Navigation',
      icon: <Network className="w-5 h-5" />,
      items: [
        { label: 'Classes Hub', path: '/classes' },
        { label: 'Group Classes Listing', path: '/classes/group' },
        { label: 'Private Coaching Detail', path: '/classes/private' },
        { label: 'Class Detail Template', path: '/classes/detail/rise-and-grind' }
      ]
    },
    {
      title: 'Conversion & Membership',
      icon: <CreditCard className="w-5 h-5" />,
      items: [
        { label: 'Group Membership (Peak/Off-Peak)', path: '/membership' },
        { label: 'Private Membership (Unleashed/Duo)', path: '/membership' }
      ]
    },
    {
      title: 'Resources & Assets',
      icon: <Users className="w-5 h-5" />,
      items: [
        { label: 'Gallery Hub', path: '/gallery' },
        { label: 'Media Kit (Asset Download)', path: '/media-kit' },
        { label: 'AI Performance Lab', path: '/ai-lab' },
        { label: 'Contact Information', path: '/#' },
        { label: 'Privacy Policy', path: '/#' }
      ]
    }
  ];

  return (
    <div className="bg-gray-50 min-h-screen py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <header className="mb-16 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">Visual Site Map</h1>
          <p className="text-gray-500 text-lg">Hierarchical structure of the Rocket Fitness wireframe prototype</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {mapData.map((section, idx) => (
            <div key={idx} className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-3 mb-8">
                <div className="bg-orange-50 p-2 rounded-lg text-[#FF6B4A]">
                  {section.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800">{section.title}</h3>
              </div>
              <ul className="space-y-4">
                {section.items.map((item, i) => (
                  <li key={i}>
                    <Link to={item.path} className="flex items-center group text-gray-600 hover:text-[#FF6B4A] transition-colors">
                      <ChevronRight className="w-4 h-4 mr-2 text-gray-300 group-hover:text-[#FF6B4A]" />
                      <span className="font-medium">{item.label}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-20 p-8 bg-orange-600 rounded-2xl text-white text-center">
          <h2 className="text-2xl font-bold mb-4">Wireframe Logic</h2>
          <p className="max-w-2xl mx-auto text-orange-100 opacity-90 leading-relaxed">
            The application flow is designed to lead users from the High-Intensity Home experience into specialized 
            Class Hubs. The differentiation between Private and Group classes is maintained throughout to ensure 
            clear value propositions for different member personas.
          </p>
        </div>
      </div>
    </div>
  );
};
