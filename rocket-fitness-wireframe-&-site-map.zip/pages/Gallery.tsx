
import React, { useState } from 'react';
import { ChevronDown, PlayCircle } from 'lucide-react';

export const Gallery: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const images = [
    "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1581009146145-b5ef03a94e77?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1594882645126-14020914d58d?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1518611012118-29a836069902?auto=format&fit=crop&q=80&w=800",
  ];

  const videos = [
    { title: "Box Lab Technique", thumb: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=800" },
    { title: "Power Punch Highlights", thumb: "https://images.unsplash.com/photo-1581009146145-b5ef03a94e77?auto=format&fit=crop&q=80&w=800" },
    { title: "Energy Exchange Session", thumb: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=800" },
  ];

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const offset = 120;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
    setIsOpen(false);
  };

  return (
    <div className="animate-in fade-in duration-700 bg-white">
      {/* Hero */}
      <div className="bg-black h-[350px] w-full flex items-center justify-center relative overflow-hidden">
        <img src="https://images.unsplash.com/photo-1593079831268-3381b0db4a77?auto=format&fit=crop&q=80&w=1600" className="absolute inset-0 w-full h-full object-cover opacity-50" />
        <h1 className="text-7xl font-extrabold text-white relative z-10 tracking-tighter uppercase text-center">Gallery</h1>
      </div>

      {/* Internal Navigation Dropdown */}
      <div className="sticky top-20 z-40 bg-white border-b border-gray-100 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 flex justify-end">
          <div className="relative">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="flex items-center space-x-2 bg-[#FF6B4A] text-white px-6 py-2 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-orange-600 transition-colors"
            >
              <span>Explore</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white shadow-2xl rounded-md border border-gray-100 py-2">
                <button onClick={() => scrollToSection('images')} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Images</button>
                <button onClick={() => scrollToSection('videos')} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Videos</button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-20">
        {/* Images Section */}
        <div id="images" className="scroll-mt-32 mb-32">
          <div className="flex flex-col items-center mb-16">
            <h2 className="text-5xl font-extrabold text-gray-900 uppercase tracking-tighter mb-4">Elite Imagery</h2>
            <div className="w-24 h-1 bg-[#FF6B4A]"></div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {images.map((src, i) => (
              <div key={i} className="aspect-square overflow-hidden group cursor-pointer bg-gray-100 border border-gray-100 rounded-lg shadow-sm hover:shadow-xl transition-all">
                <img src={src} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="Gym" />
              </div>
            ))}
          </div>
        </div>

        {/* Videos Section */}
        <div id="videos" className="scroll-mt-32">
          <div className="flex flex-col items-center mb-16">
            <h2 className="text-5xl font-extrabold text-gray-900 uppercase tracking-tighter mb-4">Training Videos</h2>
            <div className="w-24 h-1 bg-gray-900"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {videos.map((vid, i) => (
              <div key={i} className="flex flex-col space-y-4 group">
                <div className="aspect-video relative overflow-hidden rounded-xl shadow-lg">
                  <img src={vid.thumb} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition-all cursor-pointer">
                    <PlayCircle className="w-16 h-16 text-white opacity-80 group-hover:scale-110 group-hover:opacity-100 transition-all" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-800 uppercase tracking-tight text-center">{vid.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
