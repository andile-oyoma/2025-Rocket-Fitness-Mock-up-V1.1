
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown } from 'lucide-react';

export const Classes: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const offset = 120;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
    setIsOpen(false);
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      {/* Hero */}
      <div className="bg-gray-800 h-[400px] w-full flex items-center justify-center relative overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=1600" 
          className="absolute inset-0 w-full h-full object-cover opacity-40" 
          alt="Class Background"
        />
        <h1 className="text-7xl font-extrabold text-white relative z-10 tracking-tighter uppercase text-center drop-shadow-lg">
          Class Structure
        </h1>
      </div>

      {/* Internal Navigation Dropdown */}
      <div className="sticky top-20 z-40 bg-white border-b border-gray-100 py-4 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 flex justify-end">
          <div className="relative">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="flex items-center space-x-2 bg-gray-900 text-white px-6 py-2 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-[#FF6B4A] transition-colors"
            >
              <span>Jump to Section</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white shadow-2xl rounded-md border border-gray-100 py-2">
                <button onClick={() => scrollToSection('private-classes')} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Private Classes</button>
                <button onClick={() => scrollToSection('group-classes')} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Group Classes</button>
              </div>
            )}
          </div>
        </div>
      </div>

      <section className="max-w-6xl mx-auto px-4 py-24 text-center">
        <h2 className="text-6xl font-bold mb-8 text-gray-800 tracking-tighter leading-none">Transform Your Fitness<br />Journey</h2>
        <p className="text-gray-500 text-xl font-medium leading-relaxed max-w-4xl mx-auto mb-24 italic">
          Welcome to a space where strength meets determination. Whether you're building power, shedding weight, or boosting daily energy, we meet you exactly where you are.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          {/* Private Classes Section */}
          <div id="private-classes" className="space-y-10 group scroll-mt-32">
            <div className="aspect-square flex items-center justify-center overflow-hidden border border-gray-200 rounded-lg shadow-md">
               <img 
                 src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&q=80&w=1000" 
                 className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                 alt="Private Training"
               />
            </div>
            <div className="space-y-6">
              <h3 className="text-4xl font-extrabold text-[#FF6B4A] uppercase tracking-tighter">Private Classes</h3>
              <p className="text-gray-500 font-medium max-w-sm mx-auto leading-relaxed italic text-lg">Experience one-on-one coaching designed exclusively for your physiology</p>
              <Link to="/classes/private" className="inline-block border-2 border-[#FF6B4A] text-[#FF6B4A] px-10 py-3 rounded-sm font-bold uppercase tracking-widest text-xs hover:bg-[#FF6B4A] hover:text-white transition-all shadow-sm">
                Find Out More
              </Link>
            </div>
          </div>

          {/* Group Classes Section */}
          <div id="group-classes" className="space-y-10 group scroll-mt-32">
            <div className="aspect-square flex items-center justify-center overflow-hidden border border-gray-200 rounded-lg shadow-md">
               <img 
                 src="https://images.unsplash.com/photo-1518611012118-29a836069902?auto=format&fit=crop&q=80&w=1000" 
                 className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                 alt="Group Classes"
               />
            </div>
            <div className="space-y-6">
              <h3 className="text-4xl font-extrabold text-[#FF6B4A] uppercase tracking-tighter">Group Classes</h3>
              <p className="text-gray-500 font-medium max-w-sm mx-auto leading-relaxed italic text-lg">The Power of the Pack. High-energy sessions where the community drives performance.</p>
              <Link to="/classes/group" className="inline-block border-2 border-[#FF6B4A] text-[#FF6B4A] px-10 py-3 rounded-sm font-bold uppercase tracking-widest text-xs hover:bg-[#FF6B4A] hover:text-white transition-all shadow-sm">
                Find Out More
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
