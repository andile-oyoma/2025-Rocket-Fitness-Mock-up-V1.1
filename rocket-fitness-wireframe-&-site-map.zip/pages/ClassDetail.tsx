
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Check, ChevronRight } from 'lucide-react';
import { CLASSES } from '../constants';

const classImages: Record<string, string> = {
  'rise-and-grind': 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=1200',
  'power-punch': 'https://images.unsplash.com/photo-1594882645126-14020914d58d?auto=format&fit=crop&q=80&w=1200',
  'toning': 'https://images.unsplash.com/photo-1574673130244-c707aa44b74b?auto=format&fit=crop&q=80&w=1200',
  'box-lab': 'https://images.unsplash.com/photo-1552072092-2f9c11224854?auto=format&fit=crop&q=80&w=1200',
  'energy-exchange': 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200',
  'bootcamp': 'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?auto=format&fit=crop&q=80&w=1200',
  'box-flex': 'https://images.unsplash.com/photo-1518611012118-29a836069902?auto=format&fit=crop&q=80&w=1200',
};

export const ClassDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const cls = CLASSES.find((c) => c.id === id) || CLASSES[0];

  return (
    <div className="animate-in fade-in duration-700">
      {/* Breadcrumb Navigation */}
      <nav className="max-w-7xl mx-auto px-4 py-4 flex items-center space-x-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">
        <Link to="/" className="hover:text-[#FF6B4A] transition-colors">Home</Link>
        <ChevronRight className="w-3 h-3" />
        <Link to="/classes" className="hover:text-[#FF6B4A] transition-colors">Classes</Link>
        <ChevronRight className="w-3 h-3" />
        <Link to="/classes/group" className="hover:text-[#FF6B4A] transition-colors">Group Classes</Link>
        <ChevronRight className="w-3 h-3" />
        <span className="text-gray-900">{cls.title}</span>
      </nav>

      {/* Hero Header */}
      <div className="bg-gray-800 h-[400px] w-full flex items-center justify-center relative overflow-hidden">
        <img 
          src={classImages[cls.id] || "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&q=80&w=1600"} 
          className="absolute inset-0 w-full h-full object-cover opacity-40" 
          alt={cls.title}
        />
        <h1 className="text-5xl md:text-6xl font-black text-white max-w-4xl text-center leading-tight relative z-10 uppercase tracking-tighter drop-shadow-2xl">
          Detailed Class Page:<br />Individual Classes
        </h1>
      </div>

      <section className="max-w-7xl mx-auto px-4 py-24 flex flex-col md:flex-row gap-20 items-start">
        <div className="flex-1 space-y-10">
          <div className="space-y-4">
            <h2 className="text-5xl md:text-6xl font-extrabold text-gray-800 leading-none uppercase tracking-tighter">
              {cls.title}<br /><span className="text-[#FF6B4A] italic">{cls.subtitle}</span>
            </h2>
          </div>
          <p className="text-lg text-gray-500 leading-relaxed max-w-2xl font-medium italic">
            {cls.description}
          </p>
          <button className="bg-[#FF6B4A] text-white px-12 py-4 rounded-sm font-bold shadow-lg shadow-orange-100 hover:scale-105 transition-all uppercase tracking-widest text-sm">
            Join Now
          </button>
        </div>

        <div className="w-full md:w-[400px] space-y-8 pt-4">
          {cls.benefits.map((benefit, idx) => (
            <div key={idx} className="flex items-center space-x-8 group">
              <div className="border border-[#FF6B4A] p-4 rounded-md group-hover:bg-[#FF6B4A] transition-colors">
                <Check className="w-8 h-8 text-[#FF6B4A] group-hover:text-white" />
              </div>
              <span className="text-xl font-extrabold text-gray-700 leading-tight uppercase tracking-tight">{benefit}</span>
            </div>
          ))}
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 pb-24">
         <Link to="/classes/group" className="text-[#FF6B4A] font-bold hover:underline flex items-center space-x-2 text-sm uppercase tracking-widest">
           <span>←</span> <span>Back to all classes</span>
         </Link>
      </div>
    </div>
  );
};
