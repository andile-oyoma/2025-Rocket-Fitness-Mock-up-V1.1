
import React from 'react';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';
import { COLORS, TRAINERS } from '../constants';

export const Home: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-700">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 py-16 md:py-24 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="aspect-[4/3] rounded-sm overflow-hidden border border-gray-200 shadow-xl">
          <img 
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200" 
            alt="Elite Gym Environment" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="space-y-8">
          <h1 className="text-5xl md:text-7xl font-bold leading-tight" style={{ color: COLORS.primary }}>
            YOUR PATH.<br />UNLEASHED.
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed max-w-lg">
            Whether your goal is raw power or strength and conditioning, our elite environment is engineered for your evolution. A private sanctuary designed for high performance and total wellness.
          </p>
          <button className="bg-[#FF6B4A] text-white px-8 py-4 rounded-md font-bold hover:bg-[#e85a3d] transition-all transform hover:-translate-y-1">
            Book Your First Session
          </button>
        </div>
      </section>

      {/* Core Methods Section */}
      <section className="bg-white py-24 px-4">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2 className="text-5xl font-bold mb-4" style={{ color: COLORS.primary }}>Our Core Training Methods</h2>
          <p className="text-gray-500 italic">Result-Focused Methods with<br />Real, measurable results through four structured core disciplines</p>
        </div>
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { 
              title: 'Boxing Training:', 
              desc: 'Master the sweet science. Sharpen reflexes, build elite power, and torch calories with technical precision.',
              img: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=600'
            },
            { 
              title: 'Aerobic exercise:', 
              desc: 'Fuel your engine. Continuous movement to boost heart health, increase stamina, and manage weight effectively.',
              img: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=600'
            },
            { 
              title: 'Strength training:', 
              desc: 'Build your foundation. Use resistance to increase bone density, sculpt muscle, and unlock raw physical power.',
              img: 'https://images.unsplash.com/photo-1581009146145-b5ef03a94e77?auto=format&fit=crop&q=80&w=600'
            },
            { 
              title: 'HIIT:', 
              desc: 'Maximum intensity, minimum time. Short, explosive bursts to spike your metabolism and burn calories fast.',
              img: 'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?auto=format&fit=crop&q=80&w=600'
            }
          ].map((method, idx) => (
            <div key={idx} className="bg-white border border-gray-200 p-8 flex flex-col items-start text-left space-y-6 group hover:shadow-lg transition-all h-full">
              <div className="aspect-video w-full overflow-hidden">
                <img src={method.img} alt={method.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
              </div>
              <h3 className="font-bold text-xl leading-tight">{method.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed flex-grow">
                {method.desc}
              </p>
              <Link to="/classes" className="border border-[#FF6B4A] text-[#FF6B4A] px-6 py-2 rounded-sm text-sm font-semibold hover:bg-[#FF6B4A] hover:text-white transition-colors">
                Choose a Class
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Why Partner Section */}
      <section className="bg-white py-24 px-4 border-t border-gray-100">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold mb-16 text-[#FF6B4A]">Why Partner with Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            <div className="space-y-12">
              <div className="space-y-4">
                <h4 className="font-bold text-xl">Elite Coaching.</h4>
                <p className="text-gray-500 leading-relaxed">No generic routines. Every movement is tailored to your unique physiology and goals.</p>
              </div>
              <div className="space-y-4">
                <h4 className="font-bold text-xl">Environment.</h4>
                <p className="text-gray-500 leading-relaxed">No crowds. No waiting. Just a focused space designed to elevate your mental and physical state.</p>
              </div>
              <div className="space-y-4">
                <h4 className="font-bold text-xl">Total Wellness.</h4>
                <p className="text-gray-500 leading-relaxed">Integration of recovery, nutrition, and strength to ensure you don't just work out, but evolve.</p>
              </div>
            </div>
            <div className="space-y-10">
              {[
                { title: 'Personal Training', desc: 'One-on-one intensity for those who demand the best' },
                { title: 'Boutique Groups', desc: 'Small-batch classes (max 8 people) for community-driven results.' },
                { title: 'Recovery Lab', desc: 'Post-workout infrared therapy and guided mobility.' }
              ].map((item, idx) => (
                <div key={idx} className="flex items-start space-x-6">
                  <div className="border border-[#FF6B4A] p-3 rounded-md">
                    <Check className="w-5 h-5 text-[#FF6B4A]" />
                  </div>
                  <div>
                    <h5 className="font-bold text-[#FF6B4A] text-lg mb-1">{item.title}</h5>
                    <p className="text-gray-500">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Trainers Section */}
      <section className="bg-white py-24 px-4 text-center">
        <h2 className="text-5xl font-bold mb-4" style={{ color: COLORS.primary }}>Meet Your Unfair Advantage</h2>
        <p className="text-gray-500 mb-20 italic">Our coaches aren't just trainers; they are architects of human potential</p>
        
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-20">
          {TRAINERS.map((trainer, idx) => (
            <div key={idx} className="space-y-6 flex flex-col items-center">
              <div className="w-full aspect-[4/3] overflow-hidden rounded-md border border-gray-100 shadow-sm">
                <img 
                  src={idx === 0 ? "https://images.unsplash.com/photo-1567013127542-490d757e51fe?auto=format&fit=crop&q=80&w=800" : "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=800"} 
                  alt={trainer.name} 
                  className="w-full h-full object-cover" 
                />
              </div>
              <div className="space-y-4 max-w-sm">
                <p className="italic text-gray-400 font-medium">{trainer.role}</p>
                <h4 className="text-3xl font-bold text-[#FF6B4A] uppercase tracking-wide">{trainer.name}</h4>
                <p className="text-sm text-gray-500 leading-relaxed">{trainer.bio}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-16">
          <Link to="/classes" className="border border-[#FF6B4A] text-[#FF6B4A] px-10 py-3 rounded-sm font-bold hover:bg-[#FF6B4A] hover:text-white transition-all uppercase tracking-widest text-xs">
            Choose a Class
          </Link>
        </div>
      </section>

      {/* Community Gallery Section */}
      <section id="gallery" className="bg-white py-24 px-4 border-t border-gray-100">
        <h2 className="text-5xl font-bold mb-16 text-center text-[#FF6B4A]">The Community is Growing</h2>
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-6 h-[700px]">
          <div className="md:col-span-6 bg-gray-100 overflow-hidden">
             <img src="https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover" />
          </div>
          <div className="md:col-span-6 grid grid-cols-2 grid-rows-2 gap-6 h-full">
            <div className="bg-gray-100 overflow-hidden"><img src="https://images.unsplash.com/photo-1574673130244-c707aa44b74b?auto=format&fit=crop&q=80&w=600" className="w-full h-full object-cover" /></div>
            <div className="bg-gray-100 overflow-hidden"><img src="https://images.unsplash.com/photo-1593079831268-3381b0db4a77?auto=format&fit=crop&q=80&w=600" className="w-full h-full object-cover" /></div>
            <div className="bg-gray-100 overflow-hidden"><img src="https://images.unsplash.com/photo-1518611012118-29a836069902?auto=format&fit=crop&q=80&w=600" className="w-full h-full object-cover" /></div>
            <div className="bg-gray-100 overflow-hidden"><img src="https://images.unsplash.com/photo-1594882645126-14020914d58d?auto=format&fit=crop&q=80&w=600" className="w-full h-full object-cover" /></div>
          </div>
        </div>
      </section>
    </div>
  );
};
