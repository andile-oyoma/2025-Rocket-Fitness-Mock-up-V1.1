
import React from 'react';
import { Check } from 'lucide-react';
import { CLASSES } from '../constants';

export const PrivateClasses: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-700">
      <div className="bg-gray-800 h-[350px] w-full flex items-center justify-center relative overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&q=80&w=1600" 
          className="absolute inset-0 w-full h-full object-cover opacity-40" 
          alt="Private Training"
        />
        <h1 className="text-6xl font-bold text-white relative z-10 uppercase tracking-tighter text-center px-4">Private Class Page</h1>
      </div>

      <section className="max-w-5xl mx-auto px-4 py-24 text-center">
        <h2 className="text-7xl font-bold mb-6 text-gray-800 tracking-tight">Elite Private Coaching</h2>
        <p className="text-gray-500 text-xl font-medium max-w-2xl mx-auto mb-12 leading-relaxed italic">
          Tailored programs designed to bridge the gap between where you are and where you want to be
        </p>
        <button className="bg-[#FF6B4A] text-white px-12 py-3 rounded-sm font-bold mb-24 uppercase tracking-widest text-sm shadow-lg shadow-orange-100">
          Book a Time
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-20 gap-y-16 text-left">
          {CLASSES.filter(c => c.id !== 'box-flex').map((cls) => (
            <div key={cls.id} className="flex items-start space-x-6 group">
              <div className="border border-[#FF6B4A] p-3 rounded-md shrink-0 group-hover:bg-[#FF6B4A] transition-colors">
                <Check className="w-6 h-6 text-[#FF6B4A] group-hover:text-white" />
              </div>
              <div className="space-y-3">
                <h4 className="font-bold text-[#FF6B4A] text-lg uppercase tracking-wider leading-tight">
                  {cls.title} {cls.subtitle}
                </h4>
                <p className="text-sm text-gray-500 leading-relaxed font-medium">
                  {cls.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-24">
          <button className="bg-[#FF6B4A] text-white px-14 py-4 rounded-sm font-bold text-lg uppercase tracking-widest shadow-xl shadow-orange-100">
            Book a Today
          </button>
        </div>
      </section>
    </div>
  );
};
