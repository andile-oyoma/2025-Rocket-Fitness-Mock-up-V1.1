
import React from 'react';
import { Download, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { CLASSES, TRAINERS } from '../constants';

export const MediaKit: React.FC = () => {
  const brandImages = [
    { title: "Hero - Elite Gym", url: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200", category: "Environment" },
    { title: "Class Background", url: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=1600", category: "Backgrounds" },
    { title: "Private Training", url: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&q=80&w=1600", category: "Training" },
    { title: "Recovery Lab", url: "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&q=80&w=1600", category: "Environment" },
  ];

  const methodImages = [
    { title: "Boxing Training", url: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=600" },
    { title: "Aerobic Exercise", url: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=600" },
    { title: "Strength Training", url: "https://images.unsplash.com/photo-1581009146145-b5ef03a94e77?auto=format&fit=crop&q=80&w=600" },
    { title: "HIIT", url: "https://images.unsplash.com/photo-1517963879433-6ad2b056d712?auto=format&fit=crop&q=80&w=600" },
  ];

  const galleryImages = [
    "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=1200",
    "https://images.unsplash.com/photo-1574673130244-c707aa44b74b?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1593079831268-3381b0db4a77?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1518611012118-29a836069902?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1594882645126-14020914d58d?auto=format&fit=crop&q=80&w=600"
  ];

  return (
    <div className="bg-[#0f1115] min-h-screen text-white pt-12 pb-24">
      <div className="max-w-7xl mx-auto px-4">
        <header className="mb-20 text-center">
          <div className="inline-flex items-center space-x-2 bg-red-600/10 text-red-500 px-4 py-2 rounded-full mb-6 border border-red-500/20">
            <ImageIcon className="w-4 h-4" />
            <span className="text-xs font-bold tracking-widest uppercase">Brand Assets</span>
          </div>
          <h1 className="text-6xl font-black italic tracking-tighter uppercase mb-4">Media Kit</h1>
          <p className="text-gray-400 max-w-2xl mx-auto font-medium">
            Access and download high-resolution imagery used throughout the Rocket Fitness digital experience.
          </p>
        </header>

        {/* Brand Imagery */}
        <section className="mb-20">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-red-600 mb-8 border-l-4 border-red-600 pl-4">Core Visuals</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {brandImages.map((img, idx) => (
              <div key={idx} className="group bg-[#1a1d23] border border-white/5 rounded-xl overflow-hidden hover:border-red-600 transition-all">
                <div className="aspect-[4/3] relative overflow-hidden bg-gray-900">
                  <img src={img.url} className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700" alt={img.title} />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-4">
                    <a href={img.url} target="_blank" rel="noopener noreferrer" className="p-3 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-md transition-all">
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  </div>
                </div>
                <div className="p-4 flex justify-between items-center">
                  <div>
                    <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{img.category}</p>
                    <h3 className="font-bold text-sm truncate max-w-[150px]">{img.title}</h3>
                  </div>
                  <a href={img.url} download className="text-red-500 hover:text-white transition-colors">
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Training Methods */}
        <section className="mb-20">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-red-600 mb-8 border-l-4 border-red-600 pl-4">Method Disciplines</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {methodImages.map((img, idx) => (
              <div key={idx} className="group relative aspect-square rounded-xl overflow-hidden border border-white/5 shadow-2xl">
                <img src={img.url} className="w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-700" alt={img.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-4 w-full flex justify-between items-center">
                  <h4 className="text-xs font-black uppercase tracking-widest">{img.title}</h4>
                  <a href={img.url} target="_blank" rel="noopener noreferrer" className="text-white hover:text-red-500">
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Community Gallery */}
        <section className="mb-20">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-red-600 mb-8 border-l-4 border-red-600 pl-4">Community & Action</h2>
          <div className="columns-2 md:columns-3 lg:columns-4 gap-6 space-y-6">
            {galleryImages.map((url, idx) => (
              <div key={idx} className="relative group rounded-xl overflow-hidden border border-white/5 break-inside-avoid">
                <img src={url} className="w-full h-auto opacity-80 group-hover:opacity-100 transition-opacity" alt="Gallery item" />
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href={url} target="_blank" rel="noopener noreferrer" className="p-2 bg-black/60 backdrop-blur-md rounded-lg text-white hover:text-red-500">
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Team */}
        <section>
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-red-600 mb-8 border-l-4 border-red-600 pl-4">Coaching Elite</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {TRAINERS.map((trainer, idx) => (
              <div key={idx} className="flex bg-[#1a1d23] rounded-2xl overflow-hidden border border-white/5 group">
                <div className="w-1/3 aspect-[3/4] overflow-hidden">
                  <img 
                    src={idx === 0 ? "https://images.unsplash.com/photo-1567013127542-490d757e51fe?auto=format&fit=crop&q=80&w=800" : "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=800"} 
                    className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-500" 
                    alt={trainer.name} 
                  />
                </div>
                <div className="p-8 flex flex-col justify-center flex-1">
                  <p className="text-[10px] font-black text-red-600 uppercase tracking-widest mb-2">{trainer.role}</p>
                  <h3 className="text-2xl font-black uppercase tracking-tight mb-4">{trainer.name}</h3>
                  <a 
                    href={idx === 0 ? "https://images.unsplash.com/photo-1567013127542-490d757e51fe?auto=format&fit=crop&q=80&w=800" : "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=800"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-white transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download Headshot</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        <footer className="mt-32 pt-12 border-t border-white/5 text-center">
          <p className="text-gray-600 text-[10px] font-bold uppercase tracking-[0.4em]">
            Rocket Fitness &copy; 2024 - Authorized Usage Only
          </p>
        </footer>
      </div>
    </div>
  );
};
