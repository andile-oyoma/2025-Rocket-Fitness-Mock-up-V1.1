
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { GROUP_MEMBERSHIPS, PRIVATE_MEMBERSHIPS, COLORS } from '../constants';

export const Membership: React.FC = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<'group' | 'private'>('group');

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const type = params.get('type');
    if (type === 'private' || type === 'group') {
      setActiveTab(type as any);
    }
  }, [location]);

  const peakSchedule = [
    { time: '5:00am', mon: 'ROCKET RISE & GRIND', tue: '', wed: 'ENERGY EXCHANGE', thu: '', fri: 'ROCKET BOX FLEX', sat: '' },
    { time: '6:00am', mon: 'ROCKET RISE & GRIND', tue: 'POWER PUNCH', wed: 'ENERGY EXCHANGE', thu: 'ROCKET TONING', fri: 'ROCKET BOX FLEX', sat: '' },
    { time: '7:00am', mon: 'ROCKET TONING', tue: '', wed: 'ENERGY EXCHANGE', thu: '', fri: 'POWER PUNCH', sat: 'WEEKEND BURN' },
    { time: '8:00am', mon: 'BOXING LAB', tue: 'ROCKET TONING', wed: 'ROCKET BOX FLEX', thu: 'POWER PUNCH', fri: 'ENERGY EXCHANGE', sat: 'ROCKET BOOTCAMP' },
    { time: '9:00am', mon: 'ENERGY EXCHANGE', tue: '', wed: 'ROCKET TONING', thu: '', fri: 'POWER PUNCH', sat: 'ENERGY EXCHANGE' },
    { time: '12:00pm', mon: 'MID DAY GRIND', tue: '', wed: 'POWER PUNCH', thu: '', fri: 'ROCKET BOX FLEX', sat: '' },
  ];

  const offPeakSchedule = [
    { time: '16:00pm', mon: 'ROCKET TONING', tue: 'POWER PUNCH', wed: 'ROCKET BOX FLEX', thu: 'ROCKET BOOTCAMP', fri: 'ENERGY EXCHANGE', sat: '' },
    { time: '17:00pm', mon: 'POWER PUNCH', tue: 'ROCKET BOX FLEX', wed: 'ROCKET TONING', thu: 'ROCKET BOX LAB', fri: '', sat: '' },
    { time: '18:00pm', mon: 'DUSK & GRIND', tue: 'ROCKET BOX LAB', wed: 'POWER PUNCH', thu: 'ENERGY EXCHANGE', fri: '', sat: '' },
  ];

  return (
    <div className="animate-in fade-in duration-700 bg-white min-h-screen">
      <div className="bg-[#d1d5db] h-[350px] w-full flex items-center justify-center relative overflow-hidden">
        <img src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&q=80&w=1600" className="absolute inset-0 w-full h-full object-cover opacity-30" />
        <h1 className="text-6xl font-bold text-gray-800 text-center px-4 uppercase tracking-tighter leading-none relative z-10">
          {activeTab === 'group' ? 'Group Membership &\nStructure' : 'Private Membership &\nStructure'}
        </h1>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-gray-900 font-extrabold tracking-[0.2em] text-sm uppercase mb-4">
          {activeTab === 'group' ? 'YOUR TIME. YOUR TERMS.' : 'YOUR FITNESS, REFINED.'}
        </p>
        <p className="italic text-gray-500 text-lg mb-12">No long-term contracts. Just a long-term commitment to your health</p>

        {activeTab === 'private' && (
          <p className="text-gray-500 max-w-3xl mx-auto mb-16 font-medium leading-relaxed italic">
            Experience one-on-one sessions designed exclusively for your unique physiology. Bridge the gap between your current state and your peak performance with four core disciplines tailored to you.
          </p>
        )}

        <div className="flex justify-center space-x-4 mb-20">
          <button 
            onClick={() => setActiveTab('group')}
            className={`px-10 py-3 rounded-full font-bold transition-all uppercase tracking-widest text-xs ${activeTab === 'group' ? 'bg-[#FF6B4A] text-white shadow-lg' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}
          >
            Group Options
          </button>
          <button 
            onClick={() => setActiveTab('private')}
            className={`px-10 py-3 rounded-full font-bold transition-all uppercase tracking-widest text-xs ${activeTab === 'private' ? 'bg-[#FF6B4A] text-white shadow-lg' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}
          >
            Private Options
          </button>
        </div>

        {activeTab === 'group' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-4xl mx-auto">
            {GROUP_MEMBERSHIPS.map((plan) => (
              <div key={plan.name} className="border border-gray-300 p-12 text-left space-y-8 flex flex-col h-[550px]">
                <h3 className="font-extrabold text-xl uppercase tracking-tighter text-gray-800">{plan.name}</h3>
                <div className="space-y-6 flex-grow">
                  <h4 className="font-bold italic text-lg text-gray-900">Access</h4>
                  <ul className="space-y-4">
                    {plan.access.map((item, i) => (
                      <li key={i} className="text-gray-600 text-sm font-medium flex items-start">
                        <span className="mr-3 text-[#FF6B4A] text-xl leading-none">•</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <button className="border border-[#FF6B4A] text-[#FF6B4A] w-full py-3 rounded-sm font-bold uppercase tracking-widest text-xs hover:bg-[#FF6B4A] hover:text-white transition-all">
                  {plan.cta}
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PRIVATE_MEMBERSHIPS.map((plan, idx) => (
              <div key={idx} className="border border-gray-300 p-12 text-center space-y-8 flex flex-col">
                <h3 className="font-extrabold text-xl text-[#FF6B4A] uppercase tracking-tighter leading-tight h-12 flex items-center justify-center">
                  {plan.name}
                </h3>
                {plan.isDuo && <div className="text-[10px] font-bold text-gray-400 -mt-8 tracking-widest">(PER PERSON)</div>}
                <div className="space-y-6 flex-grow text-left pt-4">
                  <h4 className="font-bold italic text-gray-900">Access</h4>
                  <ul className="space-y-4">
                    {plan.access.map((item, i) => (
                      <li key={i} className="text-gray-600 text-sm font-medium flex items-start">
                        <span className="mr-3 text-[#FF6B4A] text-xl leading-none">•</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <button className="border border-[#FF6B4A] text-[#FF6B4A] w-full py-3 rounded-sm font-bold uppercase tracking-widest text-xs hover:bg-[#FF6B4A] hover:text-white transition-all">
                  {plan.cta}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Schedule Table Section (Strictly following provided screenshots) */}
        {activeTab === 'group' && (
          <div className="mt-40 text-left border-t border-gray-100 pt-20">
            <h2 className="text-5xl font-extrabold mb-12 text-center text-gray-900 uppercase tracking-tighter">Group Class Structure</h2>
            
            <div className="overflow-x-auto rounded-lg shadow-2xl mb-24">
              <table className="w-full text-center border-collapse">
                <thead>
                  <tr className="bg-red-600 text-white uppercase text-xs tracking-widest font-bold">
                    <th className="py-5 px-4 border border-red-500">Time</th>
                    <th className="py-5 px-4 border border-red-500">Monday</th>
                    <th className="py-5 px-4 border border-red-500">Tuesday</th>
                    <th className="py-5 px-4 border border-red-500">Wednesday</th>
                    <th className="py-5 px-4 border border-red-500">Thursday</th>
                    <th className="py-5 px-4 border border-red-500">Friday</th>
                    <th className="py-5 px-4 border border-red-500">Saturday</th>
                  </tr>
                </thead>
                <tbody className="bg-gray-50 text-[10px] font-bold text-gray-600 uppercase">
                  {peakSchedule.map((row, i) => (
                    <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="py-6 border border-gray-200 bg-gray-50 text-gray-800">{row.time}</td>
                      <td className="py-6 border border-gray-200">{row.mon}</td>
                      <td className="py-6 border border-gray-200">{row.tue}</td>
                      <td className="py-6 border border-gray-200">{row.wed}</td>
                      <td className="py-6 border border-gray-200">{row.thu}</td>
                      <td className="py-6 border border-gray-200">{row.fri}</td>
                      <td className="py-6 border border-gray-200">{row.sat}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 className="text-5xl font-extrabold mb-12 text-center text-gray-900 uppercase tracking-tighter">Off Peak Time</h2>
            <div className="overflow-x-auto rounded-lg shadow-2xl">
              <table className="w-full text-center border-collapse">
                <thead>
                  <tr className="bg-gray-900 text-white uppercase text-xs tracking-widest font-bold">
                    <th className="py-5 px-4 border border-gray-800">Time</th>
                    <th className="py-5 px-4 border border-gray-800">Monday</th>
                    <th className="py-5 px-4 border border-gray-800">Tuesday</th>
                    <th className="py-5 px-4 border border-gray-800">Wednesday</th>
                    <th className="py-5 px-4 border border-gray-800">Thursday</th>
                    <th className="py-5 px-4 border border-gray-800">Friday</th>
                    <th className="py-5 px-4 border border-gray-800">Saturday</th>
                  </tr>
                </thead>
                <tbody className="bg-gray-50 text-[10px] font-bold text-gray-600 uppercase">
                  {offPeakSchedule.map((row, i) => (
                    <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="py-6 border border-gray-200 bg-gray-50 text-gray-800">{row.time}</td>
                      <td className="py-6 border border-gray-200">{row.mon}</td>
                      <td className="py-6 border border-gray-200">{row.tue}</td>
                      <td className="py-6 border border-gray-200">{row.wed}</td>
                      <td className="py-6 border border-gray-200">{row.thu}</td>
                      <td className="py-6 border border-gray-200">{row.fri}</td>
                      <td className="py-6 border border-gray-200">{row.sat}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
