
import React from 'react';
import { Link } from 'react-router-dom';
import { CLASSES } from '../constants';

const classImages: Record<string, string> = {
  'rise-and-grind': 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=1200',
  'power-punch': 'https://images.unsplash.com/photo-1594882645126-14020914d58d?auto=format&fit=crop&q=80&w=1200',
  'toning': 'https://images.unsplash.com/photo-1574673130244-c707aa44b74b?auto=format&fit=crop&q=80&w=1200',
  'box-lab': 'https://images.unsplash.com/photo-1552072092-2f9c11224854?auto=format&fit=crop&q=80&w=1200',
  'energy-exchange': 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200',
  'bootcamp': 'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?auto=format&fit=crop&q=80&w=1200',
  'box-flex': 'https://images.unsplash.com/photo-1518611012118-29a836069902?auto=format&fit=crop&q=80&w=1200',
};

export const GroupClasses: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-700">
      <div className="bg-gray-800 h-[300px] w-full flex items-center justify-center relative overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=1600" 
          className="absolute inset-0 w-full h-full object-cover opacity-30" 
          alt="Group Background"
        />
        <h1 className="text-6xl font-bold text-white uppercase tracking-tighter relative z-10 text-center px-4">Group Class Page</h1>
      </div>

      <section className="max-w-4xl mx-auto px-4 py-24 text-center">
        <h2 className="text-6xl font-bold mb-8 leading-none text-gray-800 tracking-tighter">Every transformation began with a single session</h2>
        <button className="bg-[#FF6B4A] text-white px-12 py-3 rounded-sm font-bold shadow-lg shadow-orange-100 mb-24 uppercase tracking-widest text-sm">
          Schedule
        </button>

        <div className="space-y-16">
          {CLASSES.map((cls) => (
            <div key={cls.id} className="space-y-6 flex flex-col items-center">
              <div className="h-[200px] w-full flex flex-col items-center justify-center border border-gray-200 relative overflow-hidden group rounded-lg shadow-sm">
                <img 
                  src={classImages[cls.id]} 
                  className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" 
                  alt={cls.title}
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                <h4 className="text-4xl font-black relative z-10 text-white uppercase tracking-tight drop-shadow-md">{cls.title}</h4>
                <p className="text-xl font-bold text-white relative z-10 italic drop-shadow-md">{cls.subtitle}</p>
              </div>
              <Link to={`/classes/detail/${cls.id}`} className="bg-[#FF6B4A] text-white px-10 py-2 rounded-sm text-sm font-bold uppercase tracking-widest hover:scale-105 transition-all">
                Find Out More
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
