
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { 
  Sparkles, 
  Image as ImageIcon, 
  Video, 
  Edit3, 
  Search, 
  Brain, 
  Upload, 
  Loader2, 
  Download,
  AlertCircle,
  Clock,
  Layers,
  Palette,
  ChevronRight,
  Mic,
  Volume2,
  StopCircle,
  Play,
  X,
  History
} from 'lucide-react';

// Fix: Define AIStudio interface and match the global Window property declaration to resolve type and modifier mismatches.
declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    readonly aistudio: AIStudio;
    webkitAudioContext: typeof AudioContext;
  }
}

type Tab = 'image-gen' | 'image-edit' | 'video-gen' | 'assistant' | 'elite-forge' | 'imagen-studio' | 'transcribe' | 'tts';
type AspectRatio = '1:1' | '3:4' | '4:3' | '9:16' | '16:9';

const EDIT_SUGGESTIONS = [
  "Add a retro 90s film filter",
  "Remove the person in the background",
  "Make the lighting more dramatic and cinematic",
  "Add neon glowing gym weights to the scene",
  "Change the gym background to a mountain peak",
  "Apply a high-contrast black and white aesthetic",
  "Add atmospheric smoke and spotlight effects"
];

// Audio Utility Functions for PCM Decoding
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const AILab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('assistant');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [resultVideo, setResultVideo] = useState<string | null>(null);
  const [resultText, setResultText] = useState<string | null>(null);
  const [searchLinks, setSearchLinks] = useState<any[]>([]);
  
  // Audio specific state
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudioBlob, setRecordedAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Form states
  const [prompt, setPrompt] = useState('');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [useThinking, setUseThinking] = useState(false);
  const [useSearch, setUseSearch] = useState(true);
  const [latencyMode, setLatencyMode] = useState<'normal' | 'fast'>('normal');

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const ensureApiKey = async () => {
    if (activeTab === 'video-gen' || activeTab === 'elite-forge' || activeTab === 'imagen-studio' || (activeTab === 'image-gen' && imageSize !== '1K')) {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await window.aistudio.openSelectKey();
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setSelectedImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setRecordedAudioBlob(audioBlob);
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setError(null);
    } catch (err: any) {
      setError("Microphone access denied or not available.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const resetRecording = () => {
    setRecordedAudioBlob(null);
    setAudioUrl(null);
    setResultText(null);
  };

  const handleTranscribe = async () => {
    if (!recordedAudioBlob) {
      setError("Please record some audio first.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await ensureApiKey();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const audioBase64 = await blobToBase64(recordedAudioBlob);

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [
            { inlineData: { mimeType: 'audio/webm', data: audioBase64 } },
            { text: "Transcribe this audio exactly as spoken." }
          ]
        }
      });

      setResultText(response.text);
    } catch (err: any) {
      setError(err.message || "Transcription failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleTTS = async () => {
    if (!prompt) {
      setError("Please enter text to speak.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await ensureApiKey();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) throw new Error("No audio data received");

      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
      } else if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      const audioBuffer = await decodeAudioData(
        decodeBase64(base64Audio),
        audioContextRef.current,
        24000,
        1
      );

      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContextRef.current.destination);
      source.start();
      
      setResultText("Audio generated and playing...");

    } catch (err: any) {
      setError(err.message || "Text-to-speech failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateImage = async (modelType: 'standard' | 'elite') => {
    setLoading(true);
    setError(null);
    setResultImage(null);
    setResultText(null);
    setResultVideo(null);
    
    try {
      await ensureApiKey();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const modelName = modelType === 'elite' ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
      
      const response = await ai.models.generateContent({
        model: modelName,
        contents: { parts: [{ text: prompt }] },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio,
            imageSize: modelType === 'elite' ? imageSize : undefined
          }
        }
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            setResultImage(`data:image/png;base64,${part.inlineData.data}`);
          } else if (part.text) {
            setResultText(part.text);
          }
        }
      }
    } catch (err: any) {
      if (err.message?.includes("Requested entity was not found.")) {
        await window.aistudio.openSelectKey();
        setError("Session issue. Please re-select your API key and try again.");
      } else {
        setError(err.message || "Failed to generate image.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateImagen = async () => {
    setLoading(true);
    setError(null);
    setResultImage(null);
    try {
      await ensureApiKey();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt || 'A powerful fitness athlete in a high-tech gym, neon lighting, cinematic style',
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: aspectRatio,
        },
      });

      const base64EncodeString = response.generatedImages[0].image.imageBytes;
      setResultImage(`data:image/png;base64,${base64EncodeString}`);
    } catch (err: any) {
      if (err.message?.includes("Requested entity was not found.")) {
        await window.aistudio.openSelectKey();
        setError("Paid API Key required for Imagen 4.0. Please select one.");
      } else {
        setError(err.message || "Imagen generation failed.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEditImage = async () => {
    if (!selectedImage) return setError("Please upload an image first.");
    setLoading(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const base64 = selectedImage.split(',')[1];
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { inlineData: { data: base64, mimeType: 'image/jpeg' } },
            { text: prompt }
          ]
        }
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            setResultImage(`data:image/png;base64,${part.inlineData.data}`);
          } else if (part.text) {
            setResultText(part.text);
          }
        }
      }
    } catch (err: any) {
      setError(err.message || "Photo editing failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateVideo = async () => {
    setLoading(true);
    setError(null);
    setResultVideo(null);
    try {
      await ensureApiKey();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      let payload: any = {
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt || 'Dynamic training sequence at Rocket Fitness',
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: (aspectRatio === '16:9' || aspectRatio === '9:16') ? aspectRatio : '16:9'
        }
      };

      if (selectedImage) {
        payload.image = {
          imageBytes: selectedImage.split(',')[1],
          mimeType: 'image/jpeg'
        };
      }

      let operation = await ai.models.generateVideos(payload);
      
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        const aiPolling = new GoogleGenAI({ apiKey: process.env.API_KEY });
        operation = await aiPolling.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        setResultVideo(`${downloadLink}&key=${process.env.API_KEY}`);
      }
    } catch (err: any) {
      if (err.message?.includes("Requested entity was not found.")) {
        await window.aistudio.openSelectKey();
        setError("Paid key required for Video Generation.");
      } else {
        setError(err.message || "Video generation failed.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAssistant = async () => {
    setLoading(true);
    setError(null);
    setResultText(null);
    setSearchLinks([]);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      let model = 'gemini-3-flash-preview';
      let config: any = {};

      if (latencyMode === 'fast') {
        model = 'gemini-flash-lite-latest';
      } else if (useThinking) {
        model = 'gemini-3-pro-preview';
        config.thinkingConfig = { thinkingBudget: 32768 };
      }

      if (useSearch && !useThinking) {
        config.tools = [{ googleSearch: {} }];
      }

      const response = await ai.models.generateContent({
        model,
        contents: prompt || 'Give me a 7-day personalized workout plan for fat loss and muscle gain.',
        config
      });

      setResultText(response.text);
      if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
        setSearchLinks(response.candidates[0].groundingMetadata.groundingChunks);
      }
    } catch (err: any) {
      setError(err.message || "AI Coach response error.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0f1115] min-h-screen text-white pt-12">
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <header className="mb-12 text-center">
          <div className="inline-flex items-center space-x-2 bg-red-600/10 text-red-500 px-4 py-2 rounded-full mb-4 border border-red-500/20">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-bold tracking-widest uppercase">Rocket AI Laboratory</span>
          </div>
          <h1 className="text-5xl font-black italic tracking-tighter uppercase leading-none">
            The Future of <span className="text-red-600">Fitness</span>
          </h1>
          <p className="text-gray-400 mt-4 max-w-2xl mx-auto text-sm md:text-base">
            Bleeding-edge Gemini AI models for generating workout visuals, analyzing your form, or crafting the ultimate training program.
          </p>
        </header>

        <div className="flex flex-col lg:flex-row gap-8">
          <aside className="lg:w-64 shrink-0">
            <nav className="space-y-1">
              {[
                { id: 'assistant', label: 'AI Coach', icon: <Brain /> },
                { id: 'transcribe', label: 'Audio to Text', icon: <Mic /> },
                { id: 'tts', label: 'Text to Speech', icon: <Volume2 /> },
                { id: 'image-gen', label: 'Visual Studio', icon: <ImageIcon /> },
                { id: 'image-edit', label: 'Photo Refiner', icon: <Edit3 /> },
                { id: 'elite-forge', label: 'Elite Forge (3 Pro)', icon: <Layers /> },
                { id: 'imagen-studio', label: 'Imagen 4.0', icon: <Palette /> },
                { id: 'video-gen', label: 'Video Engine (Veo)', icon: <Video /> },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as Tab);
                    setResultImage(null);
                    setResultVideo(null);
                    setResultText(null);
                    setError(null);
                    setRecordedAudioBlob(null);
                    setAudioUrl(null);
                    setPrompt('');
                  }}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-bold uppercase tracking-wider transition-all ${
                    activeTab === item.id 
                      ? 'bg-red-600 text-white shadow-lg shadow-red-900/20' 
                      : 'text-gray-400 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <span className="w-5 h-5">{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>
          </aside>

          <main className="flex-grow bg-[#1a1d23] rounded-2xl border border-white/5 overflow-hidden flex flex-col min-h-[600px]">
            <div className="p-8 flex-grow">
              
              <div className="space-y-6 mb-8">
                
                {activeTab === 'transcribe' ? (
                  <div className="space-y-6">
                    <div className="flex flex-col items-center justify-center p-12 border-2 border-dashed border-white/10 rounded-2xl bg-[#0f1115]">
                      {!isRecording && !recordedAudioBlob && (
                        <>
                          <button onClick={startRecording} className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-all shadow-xl shadow-red-900/30 group">
                            <Mic className="w-8 h-8 text-white group-hover:scale-110 transition-transform" />
                          </button>
                          <p className="mt-4 text-sm font-bold text-gray-500 uppercase tracking-widest">Click to Record</p>
                        </>
                      )}
                      
                      {isRecording && (
                        <>
                          <div className="w-20 h-20 bg-red-600/20 rounded-full flex items-center justify-center animate-pulse">
                            <button onClick={stopRecording} className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-all">
                              <StopCircle className="w-6 h-6 text-white" />
                            </button>
                          </div>
                          <p className="mt-4 text-sm font-bold text-red-500 uppercase tracking-widest animate-pulse">Recording...</p>
                        </>
                      )}

                      {!isRecording && recordedAudioBlob && (
                        <>
                          <div className="flex items-center space-x-4 mb-4">
                             {audioUrl && <audio src={audioUrl} controls className="h-10 rounded-full" />}
                             <button onClick={resetRecording} className="text-xs text-gray-500 hover:text-white underline">Reset</button>
                          </div>
                          <p className="text-sm font-bold text-green-500 uppercase tracking-widest">Audio Captured</p>
                        </>
                      )}
                    </div>
                  </div>
                ) : activeTab === 'tts' ? (
                   <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Text to Speak</label>
                      <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Enter the text you want the AI coach to say..."
                        className="w-full bg-[#0f1115] border border-white/10 rounded-xl p-4 text-white focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-all outline-none min-h-[120px]"
                      />
                   </div>
                ) : (
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
                      {activeTab === 'image-edit' ? 'Editing Instructions (Nano Banana)' : 'Prompt Instructions'}
                    </label>
                    <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder={
                        activeTab === 'image-gen' || activeTab === 'elite-forge' || activeTab === 'imagen-studio' ? "Describe the fitness visual you want to generate..." :
                        activeTab === 'image-edit' ? "e.g., 'Add a retro filter' or 'Remove the person in the background'..." :
                        activeTab === 'video-gen' ? "Describe the training sequence for the AI to animate..." :
                        "Ask anything about training, nutrition, or recovery..."
                      }
                      className="w-full bg-[#0f1115] border border-white/10 rounded-xl p-4 text-white focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-all outline-none min-h-[120px]"
                    />
                    
                    {activeTab === 'image-edit' && (
                      <div className="mt-4">
                        <p className="text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-2">Quick Edits</p>
                        <div className="flex flex-wrap gap-2">
                          {EDIT_SUGGESTIONS.map((suggestion) => (
                            <button
                              key={suggestion}
                              onClick={() => setPrompt(suggestion)}
                              className="text-[10px] bg-white/5 hover:bg-white/10 border border-white/10 px-3 py-1.5 rounded-full text-gray-400 hover:text-white transition-all transform active:scale-95"
                            >
                              {suggestion}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className="flex flex-wrap gap-6 items-center">
                  {(activeTab === 'image-gen' || activeTab === 'elite-forge' || activeTab === 'imagen-studio' || activeTab === 'video-gen') && (
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Aspect Ratio</label>
                      <select 
                        value={aspectRatio}
                        onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                        className="bg-[#0f1115] border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-red-600"
                      >
                        <option value="1:1">Square (1:1)</option>
                        <option value="3:4">Portrait (3:4)</option>
                        <option value="4:3">Landscape (4:3)</option>
                        <option value="9:16">Reels/Shorts (9:16)</option>
                        <option value="16:9">Wide (16:9)</option>
                      </select>
                    </div>
                  )}

                  {activeTab === 'elite-forge' && (
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Resolution</label>
                      <select 
                        value={imageSize}
                        onChange={(e) => setImageSize(e.target.value as any)}
                        className="bg-[#0f1115] border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-red-600"
                      >
                        <option value="1K">1K HD</option>
                        <option value="2K">2K Ultra</option>
                        <option value="4K">4K Cinematic</option>
                      </select>
                    </div>
                  )}

                  {activeTab === 'assistant' && (
                    <div className="flex gap-4">
                      <label className="flex items-center space-x-2 cursor-pointer group">
                        <input 
                          type="checkbox" 
                          checked={useThinking} 
                          onChange={(e) => {
                            setUseThinking(e.target.checked);
                            if (e.target.checked) setLatencyMode('normal');
                          }}
                          className="w-4 h-4 rounded border-gray-700 bg-gray-900 text-red-600 focus:ring-red-600"
                        />
                        <span className="text-sm font-medium text-gray-400 group-hover:text-white transition-colors">Deep Thinking (Pro)</span>
                      </label>
                      <label className="flex items-center space-x-2 cursor-pointer group">
                        <input 
                          type="checkbox" 
                          checked={useSearch} 
                          onChange={(e) => setUseSearch(e.target.checked)}
                          disabled={useThinking}
                          className="w-4 h-4 rounded border-gray-700 bg-gray-900 text-red-600 focus:ring-red-600 disabled:opacity-30"
                        />
                        <span className={`text-sm font-medium transition-colors ${useThinking ? 'text-gray-600' : 'text-gray-400 group-hover:text-white'}`}>Google Search</span>
                      </label>
                    </div>
                  )}

                  {(activeTab === 'image-edit' || activeTab === 'video-gen') && (
                    <div className="flex-grow">
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Reference Image</label>
                      <div className="flex items-center space-x-4">
                        <button 
                          onClick={() => fileInputRef.current?.click()}
                          className="flex items-center space-x-2 bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2 rounded-lg transition-all text-sm"
                        >
                          <Upload className="w-4 h-4" />
                          <span>{selectedImage ? "Change Image" : "Upload Image"}</span>
                        </button>
                        {selectedImage && (
                          <div className="relative w-12 h-12 rounded border border-white/20 overflow-hidden group">
                            <img src={selectedImage} alt="Uploaded" className="w-full h-full object-cover" />
                            <button 
                              onClick={() => setSelectedImage(null)}
                              className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X className="w-4 h-4 text-white" />
                            </button>
                          </div>
                        )}
                        <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t border-white/5">
                <button
                  onClick={() => {
                    if (activeTab === 'image-gen') handleGenerateImage('standard');
                    else if (activeTab === 'elite-forge') handleGenerateImage('elite');
                    else if (activeTab === 'imagen-studio') handleGenerateImagen();
                    else if (activeTab === 'image-edit') handleEditImage();
                    else if (activeTab === 'video-gen') handleGenerateVideo();
                    else if (activeTab === 'assistant') handleAssistant();
                    else if (activeTab === 'transcribe') handleTranscribe();
                    else if (activeTab === 'tts') handleTTS();
                  }}
                  disabled={loading || (activeTab === 'transcribe' && !recordedAudioBlob) || (activeTab === 'transcribe' && isRecording) || ((activeTab === 'image-edit' || activeTab === 'video-gen') && !selectedImage)}
                  className="bg-red-600 hover:bg-red-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white px-8 py-3 rounded-xl font-bold uppercase tracking-widest text-sm flex items-center space-x-3 transition-all transform active:scale-95"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{activeTab === 'video-gen' ? 'Synthesizing...' : 'Processing...'}</span>
                    </>
                  ) : activeTab === 'transcribe' ? (
                     <>
                      <Mic className="w-4 h-4" />
                      <span>Transcribe Audio</span>
                    </>
                  ) : activeTab === 'tts' ? (
                     <>
                      <Volume2 className="w-4 h-4" />
                      <span>Generate Speech</span>
                    </>
                  ) : activeTab === 'image-edit' ? (
                    <>
                      <Edit3 className="w-4 h-4" />
                      <span>Apply Edit</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Forge Content</span>
                    </>
                  )}
                </button>
              </div>

              {error && (
                <div className="mt-6 bg-red-900/20 border border-red-500/50 p-4 rounded-xl flex items-start space-x-3 text-red-200">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <p className="text-sm">{error}</p>
                </div>
              )}

              <div className="mt-8">
                {loading && activeTab === 'video-gen' && (
                  <div className="bg-[#0f1115] rounded-2xl p-12 text-center border border-white/5">
                    <Loader2 className="w-12 h-12 animate-spin text-red-600 mx-auto mb-6" />
                    <h3 className="text-xl font-bold mb-2 uppercase tracking-tight">Generating Video...</h3>
                    <p className="text-gray-500 max-w-sm mx-auto text-sm italic">
                      "Please wait while our engine synthesizes your cinematic sequence. High-quality video processing may take up to 2 minutes."
                    </p>
                  </div>
                )}

                {!loading && (resultImage || resultVideo || resultText) && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em]">Generated Result</h3>
                      <div className="flex space-x-2">
                        {resultImage && (
                          <a href={resultImage} download="rocket-fitness-ai.png" className="text-gray-400 hover:text-white p-2">
                            <Download className="w-4 h-4" />
                          </a>
                        )}
                      </div>
                    </div>

                    <div className="bg-[#0f1115] rounded-2xl border border-white/10 overflow-hidden min-h-[300px] flex items-center justify-center relative shadow-2xl">
                      {resultImage && (
                        <div className="relative group w-full flex justify-center">
                          <img src={resultImage} alt="AI Generated" className="max-w-full max-h-[600px] object-contain" />
                          {activeTab === 'image-edit' && (
                            <div className="absolute top-4 left-4 bg-black/60 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center">
                              <History className="w-3 h-3 mr-2 text-red-500" /> Modified Result
                            </div>
                          )}
                        </div>
                      )}
                      {resultVideo && (
                        <video controls className="w-full h-auto max-h-[600px]">
                          <source src={resultVideo} type="video/mp4" />
                          Your browser does not support the video tag.
                        </video>
                      )}
                      {resultText && (
                        <div className="p-8 w-full text-gray-300 prose prose-invert max-w-none prose-sm">
                          <div className="whitespace-pre-wrap leading-relaxed">{resultText}</div>
                          {searchLinks.length > 0 && (
                            <div className="mt-8 pt-8 border-t border-white/10">
                              <h4 className="text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-4">Sources Grounding</h4>
                              <div className="flex flex-wrap gap-3">
                                {searchLinks.map((chunk, i) => (
                                  chunk.web && (
                                    <a 
                                      key={i} 
                                      href={chunk.web.uri} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="bg-white/5 hover:bg-white/10 border border-white/10 px-3 py-1.5 rounded-full text-[10px] font-bold text-red-400 flex items-center transition-colors"
                                    >
                                      {chunk.web.title} <ChevronRight className="w-3 h-3 ml-1" />
                                    </a>
                                  )
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {!loading && !resultImage && !resultVideo && !resultText && (
                  <div className="bg-[#0f1115]/50 border-2 border-dashed border-white/5 rounded-2xl p-20 text-center">
                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Sparkles className="w-8 h-8 text-gray-800" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-700 uppercase tracking-tight">Awaiting Input</h3>
                    <p className="text-gray-700 mt-2 text-sm">Select a tool and enter your prompt to start the process.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-[#1e2228] border-t border-white/5 px-8 py-4 flex items-center justify-between text-[10px] font-bold text-gray-500 uppercase tracking-widest">
              <div className="flex space-x-6">
                <span className="flex items-center space-x-2">
                  <Clock className="w-3 h-3" />
                  <span>Latency: {latencyMode === 'fast' ? 'Ultra Low' : 'Standard'}</span>
                </span>
                <span className="flex items-center space-x-2">
                  <Brain className="w-3 h-3" />
                  <span>Model: {activeTab === 'elite-forge' ? 'Pro 3' : 'Flash 3'}</span>
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                <span>Neural Core Online</span>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};
