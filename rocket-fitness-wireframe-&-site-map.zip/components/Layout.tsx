
import React, { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { Menu, X, Instagram, Facebook, Twitter, ChevronDown, Sparkles, Image as ImageIcon } from 'lucide-react';
import { COLORS } from '../constants';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isClassesOpen, setIsClassesOpen] = useState(false);
  const [isMembershipOpen, setIsMembershipOpen] = useState(false);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const navigate = useNavigate();

  const handleAnchorClick = (path: string, anchor: string) => {
    navigate(path);
    setTimeout(() => {
      const el = document.getElementById(anchor);
      if (el) {
        const offset = 100;
        const bodyRect = document.body.getBoundingClientRect().top;
        const elementRect = el.getBoundingClientRect().top;
        const elementPosition = elementRect - bodyRect;
        const offsetPosition = elementPosition - offset;

        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    }, 100);
    setIsMenuOpen(false);
    setIsGalleryOpen(false);
    setIsMembershipOpen(false);
    setIsClassesOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-100 px-4 py-4 md:px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold tracking-tight" style={{ color: COLORS.primary }}>
            Rocket<span className="text-gray-900">Fitness</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            <NavLink to="/" className={({ isActive }) => `text-sm font-medium transition-colors hover:text-[#FF6B4A] ${isActive ? 'text-[#FF6B4A]' : 'text-gray-600'}`}>
              Home
            </NavLink>
            
            {/* Classes Dropdown */}
            <div 
              className="relative group"
              onMouseEnter={() => setIsClassesOpen(true)}
              onMouseLeave={() => setIsClassesOpen(false)}
            >
              <button className="flex items-center text-sm font-medium text-gray-600 group-hover:text-[#FF6B4A] transition-colors py-2">
                Classes <ChevronDown className="w-4 h-4 ml-1" />
              </button>
              {isClassesOpen && (
                <div className="absolute top-full left-0 w-48 bg-white shadow-xl border border-gray-100 rounded-md py-2 z-50">
                  <Link to="/classes" className="block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]" onClick={() => setIsClassesOpen(false)}>All Classes</Link>
                  <Link to="/classes/private" className="block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]" onClick={() => setIsClassesOpen(false)}>Private Classes</Link>
                  <Link to="/classes/group" className="block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]" onClick={() => setIsClassesOpen(false)}>Group Classes</Link>
                </div>
              )}
            </div>
            
            {/* Membership Dropdown */}
            <div 
              className="relative group"
              onMouseEnter={() => setIsMembershipOpen(true)}
              onMouseLeave={() => setIsMembershipOpen(false)}
            >
              <button className="flex items-center text-sm font-medium text-gray-600 group-hover:text-[#FF6B4A] transition-colors py-2">
                Membership & Schedule <ChevronDown className="w-4 h-4 ml-1" />
              </button>
              {isMembershipOpen && (
                <div className="absolute top-full left-0 w-56 bg-white shadow-xl border border-gray-100 rounded-md py-2 z-50">
                  <Link to="/membership?type=private" className="block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Private Membership</Link>
                  <Link to="/membership?type=group" className="block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Group Membership</Link>
                </div>
              )}
            </div>

            {/* Gallery Dropdown */}
            <div 
              className="relative group"
              onMouseEnter={() => setIsGalleryOpen(true)}
              onMouseLeave={() => setIsGalleryOpen(false)}
            >
              <button className="flex items-center text-sm font-medium text-gray-600 group-hover:text-[#FF6B4A] transition-colors py-2">
                Gallery <ChevronDown className="w-4 h-4 ml-1" />
              </button>
              {isGalleryOpen && (
                <div className="absolute top-full left-0 w-56 bg-white shadow-xl border border-gray-100 rounded-md py-2 z-50">
                  <button onClick={() => handleAnchorClick('/gallery', 'images')} className="w-full text-left block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Images</button>
                  <button onClick={() => handleAnchorClick('/gallery', 'videos')} className="w-full text-left block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]">Videos</button>
                  <Link to="/media-kit" className="block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-[#FF6B4A]" onClick={() => setIsGalleryOpen(false)}>Media Kit</Link>
                </div>
              )}
            </div>

            <NavLink to="/ai-lab" className={({ isActive }) => `flex items-center space-x-1 text-sm font-bold transition-colors hover:text-[#FF6B4A] ${isActive ? 'text-[#FF6B4A]' : 'text-gray-900'}`}>
              <Sparkles className="w-4 h-4" /> <span>AI Lab</span>
            </NavLink>

            <button className="bg-[#FF6B4A] text-white px-6 py-2 rounded-md text-sm font-semibold hover:bg-[#e85a3d] transition-all">
              Join Now
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav Dropdown */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4 pb-4 animate-in slide-in-from-top duration-300">
            <Link to="/" className="block text-gray-600 font-medium py-2" onClick={() => setIsMenuOpen(false)}>Home</Link>
            <div className="space-y-2 pl-2">
              <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Classes</span>
              <Link to="/classes" className="block text-gray-600 font-medium py-1" onClick={() => setIsMenuOpen(false)}>All Classes</Link>
              <Link to="/classes/private" className="block text-gray-600 font-medium py-1" onClick={() => setIsMenuOpen(false)}>Private Classes</Link>
              <Link to="/classes/group" className="block text-gray-600 font-medium py-1" onClick={() => setIsMenuOpen(false)}>Group Classes</Link>
            </div>
            <Link to="/membership?type=private" className="block text-gray-600 font-medium py-2" onClick={() => setIsMenuOpen(false)}>Private Membership</Link>
            <Link to="/membership?type=group" className="block text-gray-600 font-medium py-2" onClick={() => setIsMenuOpen(false)}>Group Membership</Link>
            <Link to="/media-kit" className="block text-gray-600 font-medium py-2" onClick={() => setIsMenuOpen(false)}>Media Kit</Link>
            <Link to="/ai-lab" className="block text-gray-900 font-bold py-2" onClick={() => setIsMenuOpen(false)}>AI Lab</Link>
            <button className="w-full bg-[#FF6B4A] text-white px-6 py-3 rounded-md font-semibold">Join Now</button>
          </div>
        )}
      </nav>

      <main className="flex-grow">{children}</main>

      <footer className="bg-[#23272e] text-white py-20 px-4 md:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Logo Section */}
          <div className="flex flex-col items-start justify-start">
             <div className="relative mb-4">
                <div className="text-4xl font-black italic tracking-tighter flex flex-col leading-none">
                  <div className="flex items-center space-x-1">
                    <span className="text-white">R</span>
                    <span className="text-red-600">●</span>
                    <span className="text-white">CKET</span>
                  </div>
                  <div className="bg-red-600 text-white px-2 py-1 text-base not-italic tracking-widest font-bold mt-1 inline-block text-center rounded-sm">
                    FITNESS
                  </div>
                </div>
                {/* Flame/Rocket icon mockup */}
                <div className="absolute -top-4 -right-8 w-16 h-12">
                   <div className="w-full h-full bg-red-600 rounded-full blur-[2px] opacity-20 absolute rotate-45"></div>
                   <div className="w-8 h-4 bg-orange-500 rounded-full absolute top-2 right-0 rotate-12"></div>
                </div>
             </div>
          </div>

          {/* Navigations Section */}
          <div>
            <h4 className="font-bold text-lg mb-8 tracking-widest uppercase">NAVIGATIONS</h4>
            <ul className="space-y-4 text-sm font-medium">
              <li><Link to="/" className="text-gray-300 hover:text-white transition-colors">Home</Link></li>
              <li>
                <div className="relative group">
                  <Link to="/classes" className="text-gray-300 hover:text-white transition-colors flex items-center">
                    Classes <ChevronDown className="w-3 h-3 ml-2" />
                  </Link>
                </div>
              </li>
              <li><Link to="/membership" className="text-red-500 hover:text-red-400 transition-colors font-bold">Pricing</Link></li>
              <li><Link to="/gallery" className="text-gray-300 hover:text-white transition-colors">Gallery</Link></li>
              <li><Link to="/media-kit" className="text-gray-300 hover:text-white transition-colors">Media Kit</Link></li>
              <li><Link to="/ai-lab" className="text-gray-300 hover:text-white transition-colors">AI Lab</Link></li>
            </ul>
          </div>

          {/* Contact Information Section */}
          <div>
            <h4 className="font-bold text-lg mb-8 tracking-widest uppercase">CONTACT INFORMATION</h4>
            <div className="space-y-6 text-sm">
              <p className="text-red-500 leading-relaxed font-semibold">
                400 Jan Smuts Ave Cnr Jan Smuts Ave &,<br />
                Burnside Ave, Craighall Park, Randburg,<br />
                2196
              </p>
              <p className="text-gray-300 font-bold">
                +27 79 863 7655
              </p>
            </div>
            <div className="flex space-x-6 mt-8">
              <Instagram className="w-5 h-5 text-gray-400 hover:text-red-500 cursor-pointer" />
              <Facebook className="w-5 h-5 text-gray-400 hover:text-red-500 cursor-pointer" />
              <Twitter className="w-5 h-5 text-gray-400 hover:text-red-500 cursor-pointer" />
            </div>
          </div>

          {/* We Are Open Section */}
          <div>
            <h4 className="font-bold text-lg mb-8 tracking-widest uppercase">WE ARE OPEN</h4>
            <ul className="space-y-6 text-sm text-gray-300 font-medium">
              <li className="flex justify-between">
                <span>Mon-Thu:</span>
                <span>5:00 – 19:00</span>
              </li>
              <li className="flex justify-between">
                <span>Fri:</span>
                <span>5:00 – 12:00</span>
              </li>
              <li className="flex justify-between">
                <span>Sat:</span>
                <span>7:00 – 12:00</span>
              </li>
              <li className="flex justify-between">
                <span>Holiday:</span>
                <span>7:00 – 12:00</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="max-w-7xl mx-auto border-t border-gray-700 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 space-y-4 md:space-y-0">
          <p>© 2024 Rocket Fitness. All rights reserved.</p>
          <div className="flex space-x-6">
            <Link to="/sitemap" className="hover:text-gray-300">Sitemap</Link>
            <Link to="/#" className="hover:text-gray-300">Privacy Policy</Link>
            <Link to="/#" className="hover:text-gray-300">Terms of Service</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};
