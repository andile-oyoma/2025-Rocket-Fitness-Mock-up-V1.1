
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Classes } from './pages/Classes';
import { GroupClasses } from './pages/GroupClasses';
import { PrivateClasses } from './pages/PrivateClasses';
import { Membership } from './pages/Membership';
import { ClassDetail } from './pages/ClassDetail';
import { SiteMap } from './pages/SiteMap';
import { Gallery } from './pages/Gallery';
import { AILab } from './pages/AILab';
import { MediaKit } from './pages/MediaKit';

const App: React.FC = () => {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/classes" element={<Classes />} />
        <Route path="/classes/group" element={<GroupClasses />} />
        <Route path="/classes/private" element={<PrivateClasses />} />
        <Route path="/classes/detail/:id" element={<ClassDetail />} />
        <Route path="/membership" element={<Membership />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/sitemap" element={<SiteMap />} />
        <Route path="/ai-lab" element={<AILab />} />
        <Route path="/media-kit" element={<MediaKit />} />
      </Routes>
    </Layout>
  );
};

export default App;
