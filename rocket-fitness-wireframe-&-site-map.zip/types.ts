
export interface NavItem {
  label: string;
  path: string;
}

export interface Trainer {
  name: string;
  role: string;
  bio: string;
  imageUrl: string;
}

export interface ClassInfo {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  benefits: string[];
}

export interface MembershipPlan {
  name: string;
  price?: string;
  access: string[];
  cta: string;
  isDuo?: boolean;
}
